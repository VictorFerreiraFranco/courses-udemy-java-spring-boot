package udemy.courses.architecture.architecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArchitectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
