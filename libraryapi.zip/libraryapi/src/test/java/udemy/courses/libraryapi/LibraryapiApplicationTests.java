package udemy.courses.libraryapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
